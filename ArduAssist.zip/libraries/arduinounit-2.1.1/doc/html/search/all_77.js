var searchData=
[
  ['write',['write',['../class_fake_stream.html#a02fd44b84cc3ca6dc3f91eb9b78e097a',1,'FakeStream']]]
];

var searchData=
[
  ['byteswritten',['bytesWritten',['../class_fake_stream.html#a1b2f32a9257cba71c6056a3bc02eac6f',1,'FakeStream']]]
];

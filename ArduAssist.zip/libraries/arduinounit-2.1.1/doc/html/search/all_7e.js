var searchData=
[
  ['_7efakestream',['~FakeStream',['../class_fake_stream.html#a20cea3759f1645f9729002bdfda75dcf',1,'FakeStream']]]
];
